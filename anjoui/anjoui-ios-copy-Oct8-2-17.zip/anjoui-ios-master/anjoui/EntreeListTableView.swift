//
//  EntreeListTableView.swift
//  anjoui
//
//  Created by Kevin Li on 10/5/15.
//  Copyright © 2015 anjoui. All rights reserved.
//

import UIKit

class EntreeListTableView: UITableView {
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
