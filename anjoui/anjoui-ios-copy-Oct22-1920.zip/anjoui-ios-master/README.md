# anjoui-ios
anjoui's iOS Application which will let cooks and diners view, post, and reserve dishes on their iOS devices. 

# Technologies
* Swift for iOS
* MySQL/PHP for database and backend respectivly
  * Hosted on Amazon AWS RDS and EC2
